import EstimateTable from "./components/EstimateTable.jsx";
// import "./App.css";

function App() {
  return (
    <>
      <EstimateTable />
    </>
  );
}

export default App;
