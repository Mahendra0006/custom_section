import React, { useState, useEffect } from "react";
import axios from "axios";
import "./EstimateTable.css";

const EstimateTable = () => {
  const [sections, setSections] = useState([]);
  const [totalsum, setTotalsum] = useState(0);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchData = async () => {
      try {
        setLoading(true); 
        const response = await axios.get("/estimateData.json");
        const data = response?.data;
        setSections(data?.data?.sections);
        calculateMainTotal(data?.data?.sections);
      } catch (error) {
        console.error("Error fetching data:", error.message);
      } finally {
        setLoading(false);
      }
    };

    fetchData();
  }, []);

  const handleqty = (qty) => (qty ? qty : 0);
  const handleunitcost = (cost) => Number(cost / 100);

  const calculateItemTotal = (qty, cost) =>
    handleqty(qty) * handleunitcost(cost);

  const calculateMainTotal = (sections) => {
    let total = 0;
    sections.forEach((section) => {
      section.items.forEach((item) => {
        total += calculateItemTotal(item.quantity, item.unit_cost);
      });
    });
    setTotalsum(total);
  };

  const handleInputChange = (value, sectionIndex, itemIndex, field) => {
    const updatedSections = [...sections];
    updatedSections[sectionIndex].items[itemIndex][field] =
      field === "unit_cost" ? Number(value) : parseInt(value) || 0;
    setSections(updatedSections);
    calculateMainTotal(updatedSections);
  };

  return (
    <div className="container">
      {loading && (
        <div className="loading-spinner">
          <div className="spinner"></div>
        </div>
      )}

      <div className="header">
        <h2>Custom Section</h2>
      </div>
      <div className="total">
        Total Sum: {totalsum.toFixed(2)} <i className="fas fa-eye" />
      </div>
      <table>
        <thead>
          <tr>
            <th>Type</th>
            <th>Item Name</th>
            <th>QTY</th>
            <th>Unit Cost</th>
            <th>Unit</th>
            <th>Total</th>
            <th>Tax</th>
            <th>Cost Code</th>
            <th className="view-icon">
              <i className="fas fa-eye" />
            </th>
          </tr>
        </thead>
        <tbody>
          {sections.map((section, sectionIndex) => (
            <React.Fragment key={sectionIndex}>
              {section.items.map((item, itemIndex) => (
                <tr key={itemIndex}>
                  <td>{item.item_type_display_name}</td>
                  <td>{item.item_type_name}</td>
                  <td>
                    <input
                      type="number"
                      value={item.quantity}
                      onChange={(e) =>
                        handleInputChange(
                          e.target.value,
                          sectionIndex,
                          itemIndex,
                          "quantity"
                        )
                      }
                      className="editable-input"
                    />
                  </td>
                  <td>
                    <input
                      type="number"
                      step="0.01"
                      value={item.unit_cost}
                      onChange={(e) =>
                        handleInputChange(
                          e.target.value,
                          sectionIndex,
                          itemIndex,
                          "unit_cost"
                        )
                      }
                      className="editable-input"
                    />
                  </td>
                  <td>{item.unit ? item.unit : "N/A"}</td>
                  <td>
                    {calculateItemTotal(item.quantity, item.unit_cost).toFixed(
                      2
                    )}
                  </td>
                  <td>{`${item.tax_rate} ✓`}</td>
                  <td>{item.cost_code ? item.cost_code : "N/A"}</td>
                  <td className="view-icon">
                    <i className="fas fa-eye" />
                  </td>
                </tr>
              ))}
            </React.Fragment>
          ))}
        </tbody>
      </table>
      <div className="footer">
        <h2>Final Section</h2>
      </div>
      <table>
        <thead>
          <tr>
            <th>Type</th>
            <th>Item Name</th>
            <th>QTY</th>
            <th>Unit Cost</th>
            <th>Unit</th>
            <th>Total</th>
            <th>Tax</th>
            <th>Cost Code</th>
            <th className="view-icon">
              <i className="fas fa-eye" />
            </th>
          </tr>
        </thead>
        <tbody>
          <tr>
            <td>LBR</td>
            <td>Manual Item</td>
            <td>10</td>
            <td>$200.00</td>
            <td>Hrs</td>
            <td>$13,100.00</td>
            <td />
            <td>000 - 15-April-2023 Beta - 00</td>
            <td className="view-icon">
              <i className="fas fa-eye" />
            </td>
          </tr>
        </tbody>
      </table>
      <div className="total">
        $13,100.00 <i className="fas fa-eye" />
      </div>
    </div>
  );
};

export default EstimateTable;
